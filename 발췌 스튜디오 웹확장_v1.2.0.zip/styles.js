// 발췌 스튜디오 — Shadow DOM 안에 주입되는 스타일
// (페이지의 CSS와 서로 간섭하지 않도록 섀도 루트 내부에서만 적용된다)
window.__BALCHE_CSS = `
/* ── 발췌 스튜디오 · 저널 미니멀 ───────────────
   팔레트: 웜 화이트 #FBFBFA · 오프블랙 잉크 #2F3437
   보조 그레이 #787774 · 헤어라인 #EAEAEA
   포인트: 딥 레드 #9F2F2D
──────────────────────────────────────────────── */

:host {
  all: initial;
}

.bs-overlay {
  position: fixed;
  inset: 0;
  z-index: 2147483300;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 1.2rem;
  background: rgba(24, 23, 21, 0.45);
  backdrop-filter: blur(4px);
  font-family: "Pretendard", "Malgun Gothic", "Apple SD Gothic Neo", sans-serif;
  font-size: 16px;
  line-height: 1.5;
  color: #2f3437;
  box-sizing: border-box;
}
.bs-overlay *,
.bs-overlay *::before,
.bs-overlay *::after {
  box-sizing: border-box;
}

.bs-panel {
  display: flex;
  flex-direction: column;
  width: min(1100px, 100%);
  max-height: min(92vh, 100%);
  border: 1px solid #eaeaea;
  border-radius: 12px;
  background: #fbfbfa;
  color: #2f3437;
  box-shadow: 0 24px 64px rgba(0, 0, 0, 0.2);
  overflow: hidden;
}

.bs-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 1rem 1.4rem;
  border-bottom: 1px solid #eaeaea;
  background: rgba(255, 255, 255, 0.55);
}
.bs-header-left {
  display: flex;
  align-items: baseline;
  gap: 0.75rem;
}
.bs-title {
  font-family: "Noto Serif KR", "Nanum Myeongjo", Batang, serif;
  font-size: 1.05rem;
  font-weight: 700;
  letter-spacing: -0.02em;
}
.bs-subtitle {
  font-family: Consolas, "SF Mono", monospace;
  font-size: 0.62rem;
  font-weight: 500;
  letter-spacing: 0.14em;
  color: #787774;
}
.bs-icon-btn {
  border: none;
  background: transparent;
  color: #787774;
  font-size: 0.95rem;
  cursor: pointer;
  padding: 0.3rem 0.5rem;
  border-radius: 6px;
  font-family: inherit;
}
.bs-icon-btn:hover {
  background: #f1f0ee;
  color: #2f3437;
}

.bs-body {
  display: flex;
  flex: 1;
  min-height: 0;
  overflow: hidden;
}

.bs-preview-wrap {
  flex: 1;
  min-width: 0;
  overflow: auto;
  padding: 2rem;
  background: #f1f0ee;
  display: flex;
  align-items: flex-start;
  justify-content: center;
}

.bs-paste {
  display: flex;
  flex-direction: column;
  gap: 0.8rem;
  width: min(560px, 100%);
  margin-top: 1rem;
}
.bs-paste-hint {
  font-size: 0.84rem;
  color: #787774;
  line-height: 1.5;
  text-align: center;
}
.bs-paste textarea {
  width: 100%;
  min-height: 14rem;
  padding: 0.9rem 1rem;
  border: 1px solid #eaeaea;
  border-radius: 8px;
  background: #ffffff;
  color: #2f3437;
  font-family: inherit;
  font-size: 0.9rem;
  line-height: 1.6;
  resize: vertical;
}
.bs-paste textarea:focus {
  outline: none;
  border-color: #b9b7b2;
}

.bs-card {
  position: relative;
  flex-shrink: 0;
  max-width: 100%;
  display: flex;
  flex-direction: column;
  overflow: hidden;
  border-radius: 2px;
  box-shadow: 0 1px 2px rgba(0, 0, 0, 0.08), 0 12px 40px rgba(0, 0, 0, 0.14);
  background-repeat: repeat;
}
.bs-card-body {
  display: flex;
  flex-direction: column;
}
.bs-card-text {
  white-space: pre-wrap;
  overflow-wrap: break-word;
  cursor: text;
}
.bs-card-text::selection,
.bs-card-text *::selection {
  background: rgba(159, 47, 45, 0.22);
}
.bs-card-title {
  font-weight: 700;
  letter-spacing: -0.01em;
  line-height: 1.3;
}
.bs-card-author {
  font-weight: 500;
  letter-spacing: 0.18em;
  line-height: 1.4;
}

.bs-mark-hl {
  padding: 2px 0;
  border-radius: 2px;
  box-decoration-break: clone;
  -webkit-box-decoration-break: clone;
  color: #2f3437;
}
.bs-mark-ul {
  text-decoration: underline;
  text-decoration-thickness: 0.1em;
  text-underline-offset: calc(0.18em + 3px);
}
.bs-mark-censor {
  background: #111111;
  color: transparent;
  border-radius: 2px;
  box-decoration-break: clone;
  -webkit-box-decoration-break: clone;
}

.bs-controls {
  width: 364px;
  flex-shrink: 0;
  overflow-y: auto;
  padding: 1.1rem 1.3rem 1.5rem;
  border-left: 1px solid #eaeaea;
  background: transparent;
  display: flex;
  flex-direction: column;
  gap: 0.55rem;
}

.bs-section-title {
  margin-top: 0.9rem;
  padding-bottom: 0.3rem;
  border-bottom: 1px solid #eaeaea;
  font-size: 0.66rem;
  font-weight: 700;
  letter-spacing: 0.09em;
  color: #787774;
  text-transform: uppercase;
}
.bs-section-title:first-child {
  margin-top: 0;
}

.bs-row {
  display: flex;
  align-items: center;
  gap: 0.6rem;
}
.bs-label {
  flex-shrink: 0;
  min-width: 3.4rem;
  font-size: 0.8rem;
  color: #2f3437;
}
.bs-label-auto {
  min-width: 0;
}
.bs-push {
  margin-left: auto;
}
.bs-num {
  flex-shrink: 0;
  width: 3.7rem;
  padding: 0.35rem 0.4rem;
  border: 1px solid #eaeaea;
  border-radius: 6px;
  background: #ffffff;
  color: #2f3437;
  font-family: Consolas, "SF Mono", monospace;
  font-size: 0.74rem;
  text-align: right;
}
.bs-num:focus {
  outline: none;
  border-color: #b9b7b2;
}
.bs-hint {
  font-size: 0.73rem;
  color: #787774;
  line-height: 1.45;
}

.bs-slider {
  flex: 1;
  min-width: 0;
  -webkit-appearance: none;
  appearance: none;
  height: 4px;
  border-radius: 2px;
  background: #e3e1dc;
  outline: none;
}
.bs-slider::-webkit-slider-thumb {
  -webkit-appearance: none;
  appearance: none;
  width: 15px;
  height: 15px;
  border-radius: 50%;
  background: #2f3437;
  border: 2.5px solid #fbfbfa;
  box-shadow: 0 1px 4px rgba(0, 0, 0, 0.25);
  cursor: pointer;
}
.bs-slider::-moz-range-thumb {
  width: 11px;
  height: 11px;
  border-radius: 50%;
  background: #2f3437;
  border: 2.5px solid #fbfbfa;
  box-shadow: 0 1px 4px rgba(0, 0, 0, 0.25);
  cursor: pointer;
}
.bs-select {
  flex: 1;
  min-width: 0;
  padding: 0.42rem 0.5rem;
  border: 1px solid #eaeaea;
  border-radius: 6px;
  background: #ffffff;
  color: #2f3437;
  font-size: 0.8rem;
  font-family: inherit;
}
.bs-select:focus {
  outline: none;
  border-color: #b9b7b2;
}
.bs-input {
  flex: 1;
  min-width: 0;
  padding: 0.42rem 0.55rem;
  border: 1px solid #eaeaea;
  border-radius: 6px;
  background: #ffffff;
  color: #2f3437;
  font-size: 0.8rem;
  font-family: inherit;
}
.bs-input::placeholder {
  color: #b3b1ac;
}
.bs-input:focus {
  outline: none;
  border-color: #b9b7b2;
}
.bs-revert {
  flex-shrink: 0;
  padding: 0.2rem 0.4rem;
  font-size: 0.9rem;
  line-height: 1;
}
.bs-revert--off {
  /* 숨겨도 자리는 남겨 작품명·플랫폼 입력칸 폭이 같게 */
  visibility: hidden;
  pointer-events: none;
}
.bs-color {
  width: 2.5rem;
  height: 1.75rem;
  padding: 0.1rem;
  border: 1px solid #eaeaea;
  border-radius: 6px;
  background: #ffffff;
  cursor: pointer;
}

.bs-seg {
  display: flex;
  gap: 0.3rem;
}
.bs-seg-btn {
  flex: 1;
  padding: 0.42rem 0.2rem;
  border: 1px solid #eaeaea;
  border-radius: 6px;
  background: #ffffff;
  color: #2f3437;
  font-size: 0.75rem;
  cursor: pointer;
  transition: background 0.12s ease;
  font-family: inherit;
}
.bs-seg-btn:hover {
  background: #f5f4f2;
}
.bs-seg-btn.bs-active {
  border-color: #2f3437;
  background: #2f3437;
  color: #ffffff;
  font-weight: 600;
}

.bs-mark-row {
  display: flex;
  flex-wrap: wrap; /* 견본이 늘어 좁은 폭에서는 다음 줄로 */
  gap: 0.45rem;
  align-items: center;
}
.bs-swatch {
  width: 2.05rem;
  height: 2.05rem;
  border: 1px solid rgba(0, 0, 0, 0.14);
  border-radius: 6px;
  cursor: pointer;
  font-size: 0.76rem;
  font-weight: 700;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: transform 0.12s ease;
  font-family: inherit;
}
.bs-swatch:hover {
  transform: scale(0.96);
}
.bs-swatch-censor {
  background: #111111;
  color: #111111;
  border-color: #111111;
}
.bs-swatch-erase {
  background: #ffffff;
  color: #787774;
  border: 1px dashed #cfcdc8;
  width: auto;
  padding: 0 0.55rem;
  white-space: nowrap;
}
.bs-swatch-erase:hover {
  color: #2f3437;
}
.bs-swatch-wrap {
  position: relative;
  display: inline-flex;
}
.bs-swatch-badge {
  position: absolute;
  right: -0.25rem;
  bottom: -0.25rem;
  min-width: 1rem;
  height: 1rem;
  padding: 0 0.15rem;
  border-radius: 4px;
  background: #ffffff;
  border: 1px solid rgba(0, 0, 0, 0.18);
  color: #2f3437;
  font-size: 0.6rem;
  font-weight: 700;
  line-height: 0.9rem;
  text-align: center;
  cursor: pointer;
  user-select: none;
}
.bs-swatch-badge:hover {
  background: #f1f0ee;
}
.bs-swatch-picker {
  /* 뱃지(label)를 누르면 열리는 색 선택기. 화면에는 보이지 않는다. */
  position: absolute;
  width: 0;
  height: 0;
  opacity: 0;
  pointer-events: none;
}

.bs-rules {
  display: flex;
  flex-direction: column;
  gap: 0.4rem;
}
.bs-rule-row {
  display: flex;
  align-items: center;
  gap: 0.35rem;
}
.bs-rule-arrow {
  flex-shrink: 0;
  font-size: 0.72rem;
  color: #787774;
}
.bs-rule-remove {
  flex-shrink: 0;
  border: none;
  background: transparent;
  color: #b3b1ac;
  font-size: 0.72rem;
  cursor: pointer;
  padding: 0.25rem 0.3rem;
  border-radius: 4px;
  font-family: inherit;
}
.bs-rule-remove:hover {
  background: #fdebec;
  color: #9f2f2d;
}

.bs-check-row {
  display: flex;
  align-items: center;
  gap: 0.55rem;
}
.bs-check {
  flex-shrink: 0;
  width: 1rem;
  height: 1rem;
  accent-color: #2f3437;
  cursor: pointer;
}

.bs-tex-row {
  display: flex;
  flex-wrap: wrap;
  gap: 0.4rem;
}
.bs-tex-btn {
  flex: 1;
  padding: 0.42rem 0.3rem;
  text-align: center;
  white-space: nowrap;
  border: 1px solid rgba(0, 0, 0, 0.14);
  border-radius: 6px;
  font-size: 0.75rem;
  font-weight: 600;
  cursor: pointer;
  transition: transform 0.12s ease;
  font-family: inherit;
}
.bs-tex-btn:hover {
  transform: scale(0.97);
}

.bs-btn {
  padding: 0.48rem 0.9rem;
  border: 1px solid #eaeaea;
  border-radius: 6px;
  background: #ffffff;
  color: #2f3437;
  font-size: 0.8rem;
  font-weight: 600;
  cursor: pointer;
  transition: background 0.12s ease, transform 0.12s ease;
  font-family: inherit;
}
.bs-btn:hover {
  background: #f5f4f2;
}
.bs-btn-slim {
  align-self: flex-start;
  padding: 0.38rem 0.7rem;
  font-size: 0.75rem;
}
.bs-btn-primary {
  border-color: #9f2f2d;
  background: #9f2f2d;
  color: #ffffff;
}
.bs-btn-primary:hover {
  background: #b03a37;
  border-color: #b03a37;
}

.bs-footer {
  display: flex;
  align-items: center;
  gap: 0.6rem;
  padding: 0.85rem 1.4rem;
  border-top: 1px solid #eaeaea;
  background: rgba(255, 255, 255, 0.55);
}
.bs-status {
  flex: 1;
  font-size: 0.75rem;
  color: #787774;
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

/* 모바일 · 좁은 화면 */
@media (max-width: 760px) {
  .bs-overlay {
    padding: 0.6rem;
  }
  .bs-body {
    flex-direction: column;
    overflow-y: auto;
  }
  .bs-preview-wrap {
    flex: none;
    max-height: 44vh;
    padding: 1rem;
  }
  .bs-controls {
    width: auto;
    border-left: none;
    border-top: 1px solid #eaeaea;
    overflow-y: visible;
  }
}
`;
